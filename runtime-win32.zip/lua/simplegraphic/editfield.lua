
local editField = { }
editField.__index = editField

function editField:_replSel(text)
	local left = math.min(self.caret, self.sel)
	local right = math.max(self.caret, self.sel)
	local newBuf = self.buf:sub(1, left - 1) .. text .. self.buf:sub(right)
	if self.limit and #newBuf > self.limit then
		return
	end
	self.buf = newBuf
	self.caret = left + #text
	self.sel = nil
	self.blinkStart = GetTime()
	if self.changeFunc then
		self.changeFunc(self.buf)
	end
end

function editField:_insert(text)
	local newBuf = self.buf:sub(1, self.caret - 1) .. text .. self.buf:sub(self.caret)
	if self.limit and #newBuf > self.limit then
		return
	end
	self.buf = newBuf
	self.caret = self.caret + #text
	self.sel = nil
	self.blinkStart = GetTime()
	if self.changeFunc then
		self.changeFunc(self.buf)
	end
end

function editField:SetText(text)
	self.buf = tostring(text)
	self.caret = #self.buf + 1
	self.sel = nil
end

function editField:IsMouseOver()
	if not self.x then	
		return
	end
	local cx, cy = GetCursorPos()
	return cx >= self.x and cy >= self.y and cx < self.x + self.width and cy < self.y + self.height
end

function editField:Draw(x, y, h, inactive)
	x = x or self.x
	y = y or self.y
	h = h or self.height
	local disable = self.enableFunc and not self.enableFunc()
	if self.prompt then
		if disable then
			DrawString(x, y, "LEFT", h, "VAR", self.disableCol..self.prompt)
		else
			DrawString(x, y, "LEFT", h, "VAR", self.textCol..self.prompt..":")
		end
		x = x + DrawStringWidth(h, "VAR", self.prompt) + h/2
	end
	if disable then
		DrawString(x, y, "LEFT", h, "VAR", self.disableCol..self.leader)
		return
	elseif inactive then
		DrawString(x, y, "LEFT", h, "VAR", self.textCol..self.leader..self.inactiveCol..self.buf)
		return
	end
	if self.drag then
		local cx, cy = GetCursorPos()
		self.caret = DrawStringCursorIndex(self.height, "VAR", self.buf, cx - self.x - DrawStringWidth(self.height, "VAR", (self.prompt and self.prompt..":" or "") .. self.leader), cy - self.y)
	end
	if self.sel and self.sel ~= self.caret then
		local left = math.min(self.caret, self.sel)
		local right = math.max(self.caret, self.sel)
		local pre = self.leaderCol .. self.leader .. self.textCol .. self.buf:sub(1, left - 1)
		local sel = self.selCol .. StripEscapes(self.buf:sub(left, right - 1))
		local post = self.textCol .. self.buf:sub(right)
		DrawString(x, y, "LEFT", h, "VAR", pre)
		x = x + DrawStringWidth(h, "VAR", pre)
		local selw = DrawStringWidth(h, "VAR", sel)
		SetDrawColor(self.selBGCol)
		DrawImage(nil, x, y, selw, h)
		DrawString(x, y, "LEFT", h, "VAR", sel)
		DrawString(x + selw, y, "LEFT", h, "VAR", post)
		local caretX = (self.caret > self.sel) and x + selw or x
		if (GetTime() - self.blinkStart) % 1000 < 500 then
			SetDrawColor(self.textCol)
			DrawImage(nil, caretX, y, 1, h)
		end
	else
		local pre = self.leaderCol .. self.leader .. self.textCol .. self.buf:sub(1, self.caret - 1)
		local post = self.buf:sub(self.caret)
		DrawString(x, y, "LEFT", h, "VAR", pre)
		x = x + DrawStringWidth(h, "VAR", pre)
		DrawString(x, y, "LEFT", h, "VAR", post)
		if (GetTime() - self.blinkStart) % 1000 < 500 then
			SetDrawColor(self.textCol)
			DrawImage(nil, x, y, 1, h)
		end
	end
end

function editField:OnChar(key)
	if self.enableFunc and not self.enableFunc() then
		return
	end
	if key ~= '\b' and key:match(self.filter) and (not self.limit or #self.buf < self.limit) then
		if self.sel and self.sel ~= self.caret then
			self:_replSel(key)
		else
			self:_insert(key)
		end
	end
end

function editField:OnKeyDown(key, doubleClick)
	if self.enableFunc and not self.enableFunc() then
		return true
	end
	local shift = IsKeyDown("SHIFT")
	if key == "LEFTBUTTON" then
		if self:IsMouseOver() then
			if doubleClick then
				self.sel = 1
				self.caret = #self.buf + 1
			else
				self.drag = true
				local cx, cy = GetCursorPos()
				self.caret = DrawStringCursorIndex(self.height, "VAR", self.buf, cx - self.x - DrawStringWidth(self.height, "VAR", (self.prompt and self.prompt..":" or "") .. self.leader), cy - self.y)
				self.sel = self.caret
				self.blinkStart = GetTime()
			end
		else
			return true
		end
	elseif key == "ESCAPE" or key == "RETURN" then
		return true
	elseif IsKeyDown("CTRL") then
		if key == "a" then
			self.caret = 1
			self.sel = #self.buf + 1
		elseif key == "c" or key == "x" then
			if self.sel and self.sel ~= self.caret then
				local left = math.min(self.caret, self.sel)
				local right = math.max(self.caret, self.sel)
				Copy(self.buf:sub(left, right - 1))
				if key == "x" then
					self:_replSel("")
				end
			end
		elseif key == "v" then
			local text = Paste()
			if text then
				if self.sel and self.sel ~= self.caret then
					self:_replSel(text)
				else
					self:_insert(text)
				end
			end
		end
	elseif key == "LEFT" then
		self.sel = shift and (self.sel or self.caret) or nil
		if self.caret > 1 then
			self.caret = self.caret - 1
			self.blinkStart = GetTime()
		end
	elseif key == "RIGHT" then
		self.sel = shift and (self.sel or self.caret) or nil
		if self.caret <= #self.buf then
			self.caret = self.caret + 1
			self.blinkStart = GetTime()
		end
	elseif key == "HOME" then
		self.sel = shift and (self.sel or self.caret) or nil
		self.caret = 1
		self.blinkStart = GetTime()
	elseif key == "END" then
		self.sel = shift and (self.sel or self.caret) or nil
		self.caret = #self.buf + 1			
		self.blinkStart = GetTime()
	elseif key == "BACK" then
		if self.sel and self.sel ~= self.caret then
			self:_replSel("")
		elseif self.caret > 1 then
			self.buf = self.buf:sub(1, self.caret - 2) .. self.buf:sub(self.caret)
			self.caret = self.caret - 1
			self.sel = nil
			self.blinkStart = GetTime()
			if self.changeFunc then
				self.changeFunc(self.buf)
			end
		end
	elseif key == "DELETE" then
		if self.sel and self.sel ~= self.caret then
			self:_replSel("")
		elseif self.caret <= #self.buf then
			self.buf = self.buf:sub(1, self.caret - 1) .. self.buf:sub(self.caret + 1)
			self.sel = nil
			self.blinkStart = GetTime()
			if self.changeFunc then
				self.changeFunc(self.buf)
			end
		end
	end
end

function editField:OnKeyUp(key)
	if self.enableFunc and not self.enableFunc() then
		return
	end
	if key == "LEFTBUTTON" then
		self.drag = false
	end		
end

return function(init, prompt, filter, limit, enableFunc, changeFunc, style)
	local edit = setmetatable({ }, editField)
	edit.prompt = prompt
	edit.filter = filter or "[%w%p ]"
	edit.limit = limit
	edit.enableFunc = enableFunc
	edit.changeFunc = changeFunc
	edit.textCol = (style and style.textCol) or "^7"
	edit.inactiveCol = (style and style.inactiveCol) or "^8"
	edit.disableCol = (style and style.disableCol) or "^9"
	edit.selCol = (style and style.selCol) or "^0"
	edit.selBGCol = (style and style.selBGCol) or "^xBBBBBB"
	edit.leader = (style and style.leader) or "] "
	edit.leaderCol = (style and style.leaderCol) or "^2"
	edit.blinkStart = GetTime()
	edit:SetText(init or "")
	return edit
end